# CHARACTER ARCHIVE 1.0 (Google Apps Script)

Google Sheets + Google Drive + Apps Script + HTML/CSS/JavaScript로 만든 캐릭터 관리 웹앱 초안입니다.

## 포함 파일
- `Code.gs`: 서버 코드 및 데이터베이스 관리
- `Index.html`: 웹앱 화면
- `README.txt`: 설치 안내

## 1. Apps Script 프로젝트 만들기
1. https://script.google.com/ 에 접속합니다.
2. 새 프로젝트를 만듭니다.
3. 기본 `Code.gs` 내용을 지우고 이 폴더의 `Code.gs` 내용을 붙여넣습니다.
4. `+` 버튼 > HTML을 선택하고 파일 이름을 `Index`로 지정합니다.
5. `Index.html` 내용을 붙여넣습니다.

## 2. Google 스프레드시트 데이터베이스 만들기
1. Apps Script 편집기에서 함수 목록의 `setup`을 선택합니다.
2. 실행 버튼을 누르고 권한을 승인합니다.
3. 실행 로그에 생성된 스프레드시트 URL이 표시됩니다. 또는 Google Drive에서 `Character Archive Database`를 찾습니다.
4. 스프레드시트에는 Users, Characters, CustomFields, Folders 시트가 만들어집니다.

## 3. Google 로그인 설정
이 앱은 Google Identity Services를 사용하며 ID 토큰을 서버에서 검증합니다.

1. Google Cloud Console(https://console.cloud.google.com/)에서 Apps Script 프로젝트와 연결된 Cloud 프로젝트를 확인합니다.
2. Google Auth Platform에서 앱 정보를 설정합니다.
3. OAuth 클라이언트를 생성하고 애플리케이션 유형은 `웹 애플리케이션`으로 선택합니다.
4. Apps Script 웹앱을 배포한 뒤 실제 로그인 페이지의 브라우저 출처(origin)를 OAuth 클라이언트의 승인된 JavaScript 원본에 추가합니다. HtmlService의 실행 환경에 따라 `script.google.com`이 아닌 `googleusercontent.com` 계열 출처가 표시될 수 있으므로 브라우저 주소/개발자 도구에서 실제 origin을 확인해야 합니다.
5. OAuth 클라이언트 ID를 복사합니다.
6. Apps Script 편집기 > 프로젝트 설정 > 스크립트 속성에 다음 항목을 추가합니다.
   - 속성: `GOOGLE_CLIENT_ID`
   - 값: 방금 만든 OAuth 클라이언트 ID

**중요:** 승인된 JavaScript 원본 설정은 Google Identity Services의 보안 검사 대상입니다. 로그인 버튼이 표시되지 않거나 `origin_mismatch`가 발생하면 실제 웹앱 실행 origin을 확인해 OAuth 클라이언트 설정을 수정해야 합니다.

## 4. 웹앱 배포
1. 배포 > 새 배포 > 유형 선택 > 웹 앱
2. 다음과 같이 설정합니다.
   - 실행 사용자: 나
   - 액세스 권한: 모든 사용자
3. 배포하고 웹앱 URL을 엽니다.

앱을 처음 실행할 때 Google 로그인 버튼이 나타나야 합니다.

## 5. 공개/비공개 동작
- 비공개 캐릭터: 로그인한 소유자만 열람 및 편집 가능
- 공개 캐릭터: 생성된 공유 링크를 가진 사람이 열람 가능
- 공개 캐릭터의 대표 이미지는 링크 공개 권한으로 공유됩니다.
- 비공개로 바꾸면 대표 이미지 파일의 공유 권한도 비공개로 변경됩니다.
- 공개 링크는 `웹앱URL?character=캐릭터ID` 형태입니다.

## 6. 사용자 정의 필드
각 캐릭터 상세 화면에서 항목 추가를 눌러 항목명과 형식을 직접 정할 수 있습니다.
지원 형식: 짧은 텍스트, 긴 설명, 숫자, 날짜, URL, 이미지 URL.

대표 이미지는 파일 업로드를 지원합니다. 사용자 정의 필드의 이미지 형식은 현재 이미지 URL을 입력하는 방식입니다.

## 보안 및 운영 주의
- 스프레드시트와 Drive 파일은 웹앱 소유자 계정의 Drive에 저장됩니다.
- 웹앱 소유자는 스프레드시트와 Drive 파일에 접근할 수 있습니다.
- 공개 링크는 전달받은 사람이 열람할 수 있으므로 공개 캐릭터에는 공개해도 되는 정보만 넣으세요.
- ID 토큰 검증은 Google의 tokeninfo 엔드포인트를 사용합니다. 로그인 때마다 서버에서 검증합니다.
- 이 버전은 소규모 개인/테스트용 시작 버전입니다. 여러 사용자가 동시에 많이 쓰는 서비스로 확장하기 전에는 동시성 잠금, 업로드 제한, 감사 로그, 백업, 개인정보 안내 등을 보강하세요.
- 이미지 업로드 크기는 5MB로 제한했습니다.
- 앱의 소스 코드를 수정한 뒤에는 새 버전으로 재배포해야 합니다.

## 문제 해결
- `먼저 Apps Script 편집기에서 setup()을 실행해줘.`: `setup()`을 먼저 실행하세요.
- `GOOGLE_CLIENT_ID ... 설정`: 스크립트 속성에 클라이언트 ID를 입력하세요.
- 로그인 origin 오류: OAuth 클라이언트의 승인된 JavaScript 원본에 실제 실행 origin을 등록하세요.
- 권한 오류: Apps Script 편집기에서 `setup()`을 다시 실행해 필요한 권한을 승인했는지 확인하세요.
